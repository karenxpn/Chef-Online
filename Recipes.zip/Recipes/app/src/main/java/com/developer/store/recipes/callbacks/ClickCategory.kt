package com.developer.store.recipes.callbacks

interface ClickCategory {
    fun categoryClicked(title: String)
}