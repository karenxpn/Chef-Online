package com.developer.store.recipes.repositories

import android.content.Context
import com.developer.store.recipes.models.DishModel
import com.developer.store.recipes.services.FirebaseService
import com.google.firebase.firestore.FirebaseFirestore
import io.reactivex.Observable

class FirebaseRepository( val context: Context ): FirebaseService {

    private val ref = FirebaseFirestore.getInstance()


    override fun getData(category: String): Observable<ArrayList<DishModel>> {
        val collectionReference = ref.collection(category)
        val query: com.google.firebase.firestore.Query = collectionReference.whereEqualTo("category", category )
        val dishArray = ArrayList<DishModel>()

        return Observable.create {
            query.get().addOnCompleteListener { task ->
                if ( task.isSuccessful ) {
                    for ( snapshot in task.result!! ) {
                        val cur = snapshot.toObject(DishModel::class.java)
                        dishArray.add ( cur )
                    }
                    it.onNext(dishArray)

                }

            }
        }
    }
}